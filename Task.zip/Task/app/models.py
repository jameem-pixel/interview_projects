from django.db import models

# Create your models here.


class Student(models.Model):
    name = models.CharField(max_length=255, null=True, blank=True)
    roll_no = models.CharField(max_length=64, unique=True, db_index=True)
    dob = models.DateField(blank=True, null=True)

    def save(self, *args, **kwargs):
        super(Student, self).save(*args, **kwargs)
        if self.roll_no == "":
            self.roll_no =  "STU" + str(self.id)
        super(Student, self).save()
    
    def __str__(self):
        return self.name


class StudentMark(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    mark = models.IntegerField(null=True, blank=True, default=0)

    def __str__(self):
        return self.student.name

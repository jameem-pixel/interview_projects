
from django.contrib import admin
from django.urls import path, include
from .import views


urlpatterns = [
    path('student/',views.StudentManagement.as_view(),name='student'),
    path('student/add-mark/',views.StudentMarkManagement.as_view(),name='student_mark'),
    path('student/results/', views.StudentResultManagement.as_view(), name='student_results')
]
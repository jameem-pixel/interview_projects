from .models import Student, StudentMark
from .serializers import *
from django.http import Http404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.filters import OrderingFilter, SearchFilter
from rest_framework import status, permissions, filters, pagination, viewsets, generics
from rest_framework.response import Response
from rest_framework import serializers as rest_serializers 


# class StudentManagement(APIView):

#     def get(self, request, format=None):
#         students = Student.objects.all()
#         serializer = StudentSerializer(students, many=True)
#         return Response(serializer.data)

#     def post(self, request, format=None):
#         serializer = StudentSerializer(data=request.data)
#         if serializer.is_valid():
#             serializer.save()
#             return Response(serializer.data, status=status.HTTP_201_CREATED)
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



# class StudentMark(APIView):
#     def get(self, request, format=None):
#         students_mark = StudentMark.objects.all()
#         serializer = StudentSerializer(students_mark, many=True)
#         return Response(serializer.data)



class StudentManagement(generics.ListCreateAPIView):
    permission_classes = [permissions.AllowAny]
    serializer_class = StudentSerializer

    def get_queryset(self):
        query_set = Student.objects.all()
        return query_set
        
    def create(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if serializer.is_valid():
                data = serializer.save()
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            else:
                message = _('Please give valid inputs')
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            message = rest_utils.HTTP_REST_MESSAGES['500']
            return Response(serializer.errors, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    def list(self, request):
        try:
            serializer_class = self.get_serializer_class()
            queryset = self.get_queryset()
            serializer =  self.get_serializer(queryset, many=True)
            data = dict()
            data['results']  = serializer.data
            message = "Sucess"
            return Response(data, status=status.HTTP_200_OK)
        except Exception as e:
            message = "Internal Server Error"
            return Response(serializer.errors, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class StudentMarkManagement(generics.ListCreateAPIView):
    permission_classes = [permissions.AllowAny]
    serializer_class = StudentMarkSerializer

    def get_queryset(self):
        query_set = StudentMark.objects.all()
        return query_set
        
    def create(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if serializer.is_valid():
                data = serializer.save()
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            else:
                message = _('Please give valid inputs')
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            message = rest_utils.HTTP_REST_MESSAGES['500']
            return Response(serializer.errors, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    def list(self, request):
        try:
            serializer_class = self.get_serializer_class()
            queryset = self.get_queryset()
            serializer =  self.get_serializer(queryset, many=True)
            data = dict()
            data['results']  = serializer.data
            message = "Sucess"
            return Response(data, status=status.HTTP_200_OK)
        except Exception as e:
            message = "Internal Server Error"
            return Response(serializer.errors, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class StudentResultManagement(generics.ListCreateAPIView):
    permission_classes = [permissions.AllowAny]
    serializer_class = StudentMarkSerializer

    def get_queryset(self):
        query_set = StudentMark.objects.all()
        return query_set
        
    
    def list(self, request):
        try:
            serializer_class = self.get_serializer_class()
            queryset = self.get_queryset()
            A_GRADE_LIST = list()
            B_GRADE_LIST = list()
            C_GRADE_LIST = list()
            D_GRADE_LIST = list()
            E_GRADE_LIST = list()
            F_GRADE_LIST = list()
            for studentmark in queryset:
                if studentmark.mark <= 100 and studentmark.mark >= 91:
                    serializer =  self.get_serializer(studentmark, many=False)
                    A_GRADE_LIST.append(serializer.data)
                elif studentmark.mark <= 90 and studentmark.mark >= 81:
                    serializer =  self.get_serializer(studentmark, many=False)
                    B_GRADE_LIST.append(serializer.data)
                    
                elif studentmark.mark <= 80 and studentmark.mark >= 71:
                    serializer =  self.get_serializer(studentmark, many=False)
                    C_GRADE_LIST.append(serializer.data)
                    
                elif studentmark.mark <= 70 and studentmark.mark >= 61:
                    serializer =  self.get_serializer(studentmark, many=False)
                    D_GRADE_LIST.append(serializer.data)
                    
                elif studentmark.mark <= 60 and studentmark.mark >= 55:
                    serializer =  self.get_serializer(studentmark, many=False)
                    E_GRADE_LIST.append(serializer.data)
                    
                elif studentmark.mark < 55:
                    serializer =  self.get_serializer(studentmark, many=False)
                    F_GRADE_LIST.append(serializer.data)
            data = dict()
            data['A-Grade'] = A_GRADE_LIST
            data['B-Grade'] = B_GRADE_LIST
            data['C-Grade'] = C_GRADE_LIST
            data['D-Grade'] = D_GRADE_LIST
            data['E-Grade'] = E_GRADE_LIST   
            data['F-Grade'] = F_GRADE_LIST  

            data['distinction_percentage'] = int(len(A_GRADE_LIST))//int(len(A_GRADE_LIST) +len(B_GRADE_LIST)+len(C_GRADE_LIST)+len(D_GRADE_LIST)+len(E_GRADE_LIST)+len(F_GRADE_LIST) )
            data['first_class_percentage'] = int((len(B_GRADE_LIST)+len(C_GRADE_LIST)))//int(len(A_GRADE_LIST) +len(B_GRADE_LIST)+len(C_GRADE_LIST)+len(D_GRADE_LIST)+len(E_GRADE_LIST)+len(F_GRADE_LIST)) 
            data['pass_percentage'] = int(((len(A_GRADE_LIST) +len(B_GRADE_LIST)+len(C_GRADE_LIST)+len(D_GRADE_LIST)+len(E_GRADE_LIST)+len(F_GRADE_LIST))-(len(C_GRADE_LIST))))//int(len(A_GRADE_LIST) +len(B_GRADE_LIST)+len(C_GRADE_LIST)+len(D_GRADE_LIST)+len(E_GRADE_LIST)+len(F_GRADE_LIST))
            message = "Sucess"
            return Response(data, status=status.HTTP_200_OK)
        except Exception as e:
            print('e :', e)
            message = "Internal Server Error"
            return Response(status=status.HTTP_500_INTERNAL_SERVER_ERROR)